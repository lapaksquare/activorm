<?php 

// GENERAL
$lang['ganti_bahasa'] = "Change Language";
$lang['english_lang'] = "English";
$lang['indo_lang'] = "Indonesia";

$lang['who_is_bo_sanchez'] = 'Who is Bo Sanchez ?';
$lang['detail_bo_sanchez'] = 'My mission is to bless you. My mission is to help you live life to the full. And my credentials for writing to you? I’ve failed more times than many others. And because I’ve failed so many times and learned from my failures, I’m successful beyond my wildest dreams.';


?>