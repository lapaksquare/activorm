<?php 

// GENERAL
$lang['ganti_bahasa'] = "Ganti Bahasa";
$lang['indo_lang'] = "Bahasa Indonesia";
$lang['english_lang'] = "Bahasa Inggris";

$lang['who_is_bo_sanchez'] = 'Siapa Bo Sanchez?';
$lang['detail_bo_sanchez'] = 'Misi saya adalah untuk memberkati Anda. Misi saya adalah untuk membantu Anda menjalani hidup dengan penuh. Dan kredensial saya untuk menulis kepada Anda? Saya telah gagal kali lebih daripada banyak orang lain. Dan karena saya telah gagal berkali-kali dan belajar dari kegagalan saya, saya berhasil melebihi impian terliar saya.';

?>