				</div>
			</div>	
		</div>	
		
		<?php echo $js_tags; ?>
		
	</body>
</html>