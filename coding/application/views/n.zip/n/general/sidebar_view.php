<div class="td-sidebar hidden-print">

	<?php 
	$menus = array(
		'home' => array(
			'name' => 'Home',
			'url' => base_url() . 'admin/home'
		),
		'account' => array(
			'name' => 'Account',
			'url' => '#',
			'child' => array(
				'member_account' => array(
					'name' => 'Member Account',
					'url' => base_url() . 'admin/member/member_account'
				),
				'business_account' => array(
					'name' => 'Business Account',
					'url' => base_url() . 'admin/member/business_account'
				),
				'add_invite_member' => array(
					'name' => 'Add/Invite Member',
					'url' => base_url() . 'admin/member/add_account'
				)
			)
		),
		'featured' => array(
			'name' => 'Featured',
			'url' => '#',
			'child' => array(
				'prize_homepage' => array(
					'name' => 'Prize in Homepage',
					'url' => base_url() . 'admin/featured/prize_homepage',
				),
				'logo_homepage' => array(
					'name' => 'Logo in Homepage',
					'url' => base_url() . 'admin/featured/logo_homepage'
				)
			)
		),
		'prize' => array(
			'name' => 'Prize',
			'url' => base_url() . 'admin/prize'		
		),
		'project' => array(
			'name' => 'Project',
			'url' => base_url() . 'admin/project',
			'child' => array(
				'project_draft' => array(
					'name' => 'Draft',
					'url' => '#'
				),
				'project_pending' => array(
					'name' => 'Pending',
					'url' => '#'
				),
				'project_ongoing' => array(
					'name' => 'On-Going',
					'url' => '#'
				),
				'project_closed' => array(
					'name' => 'Closed',
					'url' => '#'
				)
			)		
		)
	);
	?>

	<ul class="nav td-sidenav">
		
		<?php 
		foreach($menus as $k=>$v){
			$class = ($menu == $k) ? 'class="active"' : '';
		?>
		<li <?php echo $class; ?>><a href="<?php echo $v['url']; ?>"><?php echo $v['name']; ?></a>
			
			<?php if (!empty($v['child'])){ ?>
			<ul class="nav">
				<?php foreach($v['child'] as $a=>$b){ 
					$class = (!empty($menu_child) && $menu_child == $a) ? 'class="active"' : '';
					?>
		    	<li <?php echo $class; ?>><a href="<?php echo $b['url']; ?>"><?php echo $b['name']; ?></a></li>
		    	<?php } ?>
		  	</ul>
			<?php } ?>
			
		</li>
		<?php 	
		}
		?>
		
		<?php /*
		 * <ul class="nav">
		    	<li><a href="#">Draft <span class="badge pull-right">5</span></a></li>
		    	<li><a href="#">Pending <span class="badge pull-right">2</span></a></li>
		    	<li><a href="#">On-Going <span class="badge pull-right">2</span></a></li>
		    	<li><a href="#">Closed <span class="badge pull-right">2</span></a></li>
		  	</ul>
		 * */ ?>
		
	</ul>

</div>